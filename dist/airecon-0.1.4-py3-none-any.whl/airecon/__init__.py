"""AIRecon — AI-powered security reconnaissance."""
__version__ = "0.1.4"
