"""AIRecon TUI application."""
