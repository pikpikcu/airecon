"""AIRecon TUI widgets."""
